#include <superkarel.h>

void turn_right();
void turn_around();
void chess();

int main(){
    turn_on("round2.kw");
    set_step_delay(100);
chess();



    turn_off();
    return 0;
}
void turn_right(){
    turn_left();
    turn_left();
    turn_left();
}
void turn_around(){
    turn_left();
    turn_left();
}
void chess(){
    turn_left();
    step();
    put_beeper();
    while(front_is_clear()){
        step();
    
    if(front_is_blocked() && right_is_blocked() && facing_north()){
        turn_off();
    }
while(front_is_blocked() && facing_north()){
        turn_right();
        step();
        turn_right();
        put_beeper();
        step();
    }
        step();
        put_beeper();
while(front_is_blocked() && facing_south()){
        turn_left();
        step();
        turn_left();
        step();
        put_beeper();
}
if(front_is_blocked() && beepers_present()){
    turn_around();
    pick_beeper();
    while(front_is_clear()){
        step();
    if(beepers_present()){
            pick_beeper();
    }
    }
}
    
    
      
   
  
}
turn_around();
  put_beeper();

    while(front_is_clear()){
        step();
    if(front_is_blocked() && right_is_blocked() && facing_north()){
        turn_off();
    }
while(front_is_blocked() && facing_north()){
        turn_right();
        step();
        turn_right();
        put_beeper();
        step();
    }
        step();
        put_beeper();
while(front_is_blocked() && facing_south()){
        turn_left();
        step();
        turn_left();
        step();
        put_beeper();
   
}
}
}
