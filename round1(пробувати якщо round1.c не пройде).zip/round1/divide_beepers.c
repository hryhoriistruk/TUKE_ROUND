#include <superkarel.h>

void turn_right();
void divide();
void turn_around();
int main(){
        turn_on("round1.kw");
        set_step_delay(100);
step();

    divide();
        turn_off();
    return 0;
}
void turn_right(){
    turn_left();
    turn_left();
    turn_left();
}
void divide(){
    while(beepers_present()){
        pick_beeper();
    }
    while(beepers_in_bag()){
    put_beeper();
    step();
    put_beeper();
    turn_around();
    step();
    turn_around();
    }
}
void turn_around(){
    turn_left();
    turn_left();
}
