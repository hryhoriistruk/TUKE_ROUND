#include <superkarel.h>

void turn_right();
void turn_around();
void recursion();
void recursion1();
int main(){
    turn_on("round5.kw");
    set_step_delay(100);
    while(not_facing_west()){
        turn_left();
    }
    while(front_is_clear()){
        step();
    if(front_is_blocked() && facing_west() && left_is_clear()){
            turn_left();
    }
    }

    
    
recursion();
recursion1();
      


      turn_off();
      return 0;
}
void turn_right(){
    turn_left();
    turn_left();
    turn_left();
}
void turn_around(){
    turn_left();
    turn_left();
}
void recursion(){
    while(not_facing_north()){
        turn_right();
    }
     step();
    step();
    if (front_is_clear()){
        recursion();
    }
 else {
    turn_left();
    turn_left();
 }
  step();
  }

void recursion1(){
if (not_facing_east()) {
    turn_left();
}
      step();
    step();
    if (front_is_clear()){
        recursion1();
    }
 else {
    turn_left();
    turn_left();
 }
  step();
  }
