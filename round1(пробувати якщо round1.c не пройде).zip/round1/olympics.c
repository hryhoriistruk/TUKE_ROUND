#include <superkarel.h>

    void turn_right();
    void turn_around();
    void jump_over();


    int main(){
    turn_on("task_1.kw");
        set_step_delay(100);
   if(front_is_blocked() && left_is_clear()){
    turn_left();
}
else if(front_is_clear()){
    put_beeper();
    while(front_is_clear()){
    step();
    if(beepers_present() == true){
        pick_beeper();
    }
  }  
    turn_left();
}
        
  
while(no_beepers_in_bag()){
step();
    jump_over();

}




    turn_off();
        return 0;
    }
    void turn_right(){
    turn_left();
    turn_left();
    turn_left();
    }
    void turn_around(){
        turn_left();
        turn_left();
    }
    void jump_over(){
   if(right_is_clear()){
        turn_right();

   }
   if(front_is_blocked() && right_is_blocked() && left_is_blocked()){
   turn_around();

   }
   
   else if(front_is_blocked() && left_is_clear()){
    turn_left(); 
}
    if(beepers_present()){
        pick_beeper();
    }


    }

