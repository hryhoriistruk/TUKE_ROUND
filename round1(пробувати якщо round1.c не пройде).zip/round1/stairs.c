#include <superkarel.h>

void turn_right();
void stairs();
void turn_around();

int main(){
    turn_on("round4.kw");
    set_step_delay(100);
while(front_is_clear()){
        step();

}
turn_left();
stairs();



    turn_off();
    return 0;
}
void turn_right(){
    turn_left();
    turn_left();
    turn_left();
}
void turn_around(){
    turn_left();
    turn_left();
}
void stairs(){
    while(1){
        while(beepers_present()){
                pick_beeper();
      }
      if(front_is_blocked() && right_is_clear() && facing_east()){
            turn_around();
    step();
    while(beepers_in_bag()){
        put_beeper();

    }
    turn_around();
    turn_off();

      }
      if(front_is_blocked() && facing_east()){
                turn_left();
      }
      while(right_is_blocked() && facing_north()){
            step();
      if(right_is_clear()){
            turn_right();
      while(front_is_clear()){
             step();
      while(beepers_present()){
            pick_beeper();
      }
      }
      
      }
      }
      
    }
  
}
