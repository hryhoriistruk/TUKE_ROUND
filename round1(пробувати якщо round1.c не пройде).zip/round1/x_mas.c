#include <superkarel.h>

void turn_right();
void x_mas();
void turn_around();

int main(){
    turn_on("round3.kw");
    set_step_delay(30);
    x_mas();




    turn_off();
    return 0;
}
void turn_right(){
    turn_left();
    turn_left();
    turn_left();

}
void turn_around(){
    turn_left();
    turn_left();
}
void x_mas(){
    while(front_is_clear()){
        step();
    if(front_is_blocked() && right_is_clear() && facing_east()){
        turn_right();
        while(front_is_clear()){
            step();
        }
    }


    if(facing_west() &&  left_is_clear()){
            turn_around();
            step(); 
            put_beeper();
            turn_around();
            while(front_is_clear()){
                step();
                
            }
    }
    if(front_is_blocked() && facing_east()){
        turn_around();
    }
    if(front_is_blocked() && facing_west()){
        turn_right();
        step();
        turn_right();
    }
    
    
    }
    while(not_facing_west()){
            turn_left();

    }
  
 while(front_is_clear()){
        step();
    if(front_is_blocked() && left_is_clear() && facing_west()){
        while(not_facing_east()){
            turn_left();
        }
        while(no_beepers_present()){
            turn_right();
            step();
        if(no_beepers_present()){
            turn_around();
            step();
            turn_right();
            step();
        }       
        }   
        while(not_facing_north()){
            turn_left();
        }
        step();
        turn_right();
        step();
        put_beeper();
        put_beeper();
            while(front_is_clear()){
                step();
            if(front_is_blocked() && facing_east()){
                turn_right();
            }
            if(front_is_blocked() && facing_south()){
                turn_left();
                turn_off();
            }
            }
    
        }
    


    if(facing_east() && right_is_clear()){
            turn_around();
            step(); 
            put_beeper();
            turn_around();
            while(front_is_clear()){
                step();
                
            }
    }
    if(front_is_blocked() && facing_west()){
        turn_around();
    }
    if(front_is_blocked() && facing_east()){
        turn_left();
        step();
        turn_left();
    }

    
}
while(not_facing_west()){
        turn_left();
}
while(no_beepers_present()){
        turn_right();
        step();
 if(no_beepers_present()){
        turn_left();
        step();
        turn_right();
        step();
 }
}
}

